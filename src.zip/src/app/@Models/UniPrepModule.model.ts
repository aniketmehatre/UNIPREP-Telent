export interface UniPrepModuleModel {
    created_at: any;
    deleted_at: any;
    module_name:string;
    id:number;
    status:number;
    updated_a: any
}