export interface ReadQuestion {
    status: string,
    message: string
}
