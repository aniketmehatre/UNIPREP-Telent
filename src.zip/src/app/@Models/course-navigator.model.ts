export interface EducatiionsRec {
    id: number
    specialization_id: number
    education_id: number
    degree_name: string
    status: number
    created_at: string
  }