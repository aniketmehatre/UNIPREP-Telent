export interface Univercity {
    id: number;
    name: string;
    status: number;
    created_at?: any;
    updated_at?: any;
    deleted_at?: any;
}