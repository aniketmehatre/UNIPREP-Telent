
export interface LocationData {
    created_at: any;
    deleted_at: any;
    district:string;
    id:number;
    state:string;
    status:number;
    updated_at:any;
  }