export interface CountryandCurrency {
    country: string;
    currency_code: string;
  }