import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uni-joboffercomparisontool',
  templateUrl: './joboffercomparisontool.component.html',
  styleUrls: ['./joboffercomparisontool.component.scss']
})
export class JoboffercomparisontoolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
