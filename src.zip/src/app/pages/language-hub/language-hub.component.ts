import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uni-language-hub',
  templateUrl: './language-hub.component.html',
  styleUrls: ['./language-hub.component.scss']
})
export class LanguageHubComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
