import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uni-education-tools',
  templateUrl: './education-tools.component.html',
  styleUrls: ['./education-tools.component.scss']
})
export class EducationToolsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
