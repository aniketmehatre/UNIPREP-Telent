export const EducationToolsData = [
    {
        title: "Course Navigator",
        description: "This tool lets you get a global travel visa with the help of few easy steps",
        image: "../../../uniprep-assets/images/founderstool/foundersacademy.svg",
        url: "/pages/education-tools/course-navigator"
    },
    {
        title: "Politician Insights",
        description: "This tool lets you get a polician insights with the help of few easy steps",
        image: "../../../uniprep-assets/images/founderstool/foundersacademy.svg",
        url: "/pages/education-tools/politician-insights"
    },
    {
        title: "Global Study Visa",
        description: "This tool lets you get a global travel visa with the help of few easy steps",
        image: "../../../uniprep-assets/images/founderstool/foundersacademy.svg",
        url: "/pages/education-tools/study-visa"
    },
    {
        title: "Country Insights",
        description: "This tool lets you get a global travel visa with the help of few easy steps",
        image: "../../../uniprep-assets/images/founderstool/foundersacademy.svg",
        url: "/pages/education-tools/country-insights"
    },
]