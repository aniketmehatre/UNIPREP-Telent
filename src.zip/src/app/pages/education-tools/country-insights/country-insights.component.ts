import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uni-country-insights',
  templateUrl: './country-insights.component.html',
  styleUrls: ['./country-insights.component.scss']
})
export class CountryInsightsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
