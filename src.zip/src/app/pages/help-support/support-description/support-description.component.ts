import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'uni-support-description',
    templateUrl: './support-description.component.html',
    styleUrls: ['./support-description.component.scss']
})
export class SupportDescriptionComponent implements OnInit {

    constructor() {
    }

    ngOnInit(): void {
    }

}
