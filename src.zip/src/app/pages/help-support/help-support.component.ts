import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'uni-help-support',
    templateUrl: './help-support.component.html',
    styleUrls: ['./help-support.component.scss']
})
export class HelpSupportComponent implements OnInit {

    constructor() {
    }

    ngOnInit(): void {
    }

}
