import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'uni-support-query',
    templateUrl: './support-query.component.html',
    styleUrls: ['./support-query.component.scss']
})
export class SupportQueryComponent implements OnInit {

    constructor() {
    }

    ngOnInit(): void {
    }

}
