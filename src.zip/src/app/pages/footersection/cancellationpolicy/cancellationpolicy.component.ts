import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uni-cancellationpolicy',
  templateUrl: './cancellationpolicy.component.html',
  styleUrls: ['./cancellationpolicy.component.scss']
})
export class CancellationpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
